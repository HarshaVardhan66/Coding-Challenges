from flask import Flask, render_template, request
app = Flask(__name__)

def estimate(in_income, salary_growth_rate, savings_rate, age):
	cash_flow = [in_income*savings_rate]
	income_list = [in_income]
	curr_income = in_income
	retirement_age=age
	while True:
	    for i in range(1,85-age+1):
	        curr_income = curr_income*(1+salary_growth_rate)
	        income_list.append(curr_income)
	        curr_savings = curr_income * savings_rate
	        if age+ i<retirement_age:
	            updated_cf = cash_flow[-1]* (1.1)
	            cash_flow.append(curr_savings+updated_cf)
	        else:
	            updated_cf = (cash_flow[-1]- curr_income*(1-savings_rate))* (1.1)
	            cash_flow.append(updated_cf)
	    if cash_flow[-1]>=0:
	        break

	    cash_flow = [in_income*savings_rate]
	    retirement_age+=1
	    curr_income = in_income
	return [retirement_age, cash_flow]


@app.route('/')
def index():
   return render_template('index.html')


@app.route('/result', methods=['POST'])
def result():
	data = request.form
	init_income = int(data['init_income'])
	salary_growth_rate = int(data['salary_growth_rate'])*0.01
	savings_rate= int(data['savings_rate']) * 0.01
	age = int(data['age'])
	result = estimate(init_income, salary_growth_rate, savings_rate, age)
	value = result[0]
	cash_flow = result[1]

	len_cf=len(cash_flow)
	retirement_ages=[]
	for i in range(10,100,10):
		result = estimate(init_income, salary_growth_rate, i*0.01, age)
		retirement_ages.append(result[0])
	cash_flow = ["{:.2f}".format(i) for i in cash_flow]
	return render_template('result.html', value=value, cash_flow=cash_flow, age=age,len_cf=len_cf,retirement_ages=retirement_ages)


if __name__ == '__main__':
   app.run(debug=True)