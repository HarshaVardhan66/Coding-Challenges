import quandl
from statistics import stdev

def calc(mr7):
    mr_product = 1
    for mr in mr7:
        mr_product *= (1+float(mr/100))
    cagr = (mr_product**(len(mr7)/12)-1)*100
    return cagr


quandl.ApiConfig.api_key = 'pi_AF9J7BSxr8txzqZ-z'
fund_codes = ['AMFI/119578', 'AMFI/119578', 'AMFI/114458', 'AMFI/120267', 'AMFI/120465', 'AMFI/118269', 'AMFI/119893', 'AMFI/118825']

a = []

"""for i in fund_codes:
a.append(quandl.get('AMFI/119578', column_index='1', collapse='monthly'))"""

b = quandl.get('AMFI/119578', column_index='1', start_date='2015-01-01', end_date='2020-01-01',  collapse='monthly')

d = dict()

a = b.index
for i in range(len(a)):
    if str(a[i])[:4] in d:
        d[str(a[i])[:4]].append(b.iloc[i][0])
    else:
        d[str(a[i])[:4]]=[b.iloc[i][0]]

rf = 6
l = []
s = []
mr7 = []
for mrlist in d:
    mr7 += [float(x) for x in mrlist]

mrval = []
for i in range(1,len(mr7)):
    if mr7[i-1] !=0:
        mrval.append((mr7[i]-mr7[i-1])/mr7[i-1])

rp = calc(mrval)
sd = stdev(mrval)
sharpe = (rp-rf)/(sd*(12**(1/2)))

print(rp, sd, sharpe)
